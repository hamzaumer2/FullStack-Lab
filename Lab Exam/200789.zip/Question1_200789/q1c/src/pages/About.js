import React from 'react'

export default function About() {
return(
<div>
  <h1>About Page Hamza Umer 200789</h1>
</div>)
}
