import React from 'react'
import {Form, Button} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

export default function Contact() {
  return(
    <div>
      <h1>Contact Page Hamza Umer 200789</h1>
    </div>)
  }
