import React from 'react'
import {Form, Button} from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function FormComp() {
  const [name, setName] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [country, setCountry] = React.useState("");
  const history = useNavigate();
  const submitForm = () => {
    axios.post('http://localhost:8080/user/new', {name: name, password: password, country: country}).then((res) => {
      console.log('res', res);
      alert('User created successfully')
      history('/');
    })
  }

  return (
    <div className='row container'>
    <Form className="col-md-8">
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Name</Form.Label>
        <Form.Control value={name} onChange={(e) => setName(e.target.value)} type="name" placeholder="Name" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Password</Form.Label>
        <Form.Control value={[password]} onChange={(e) => setPassword(e.target.value)} type = "password" placeholder='********' />
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Country</Form.Label>
        <Form.Control value={[country]} onChange={(e) => setCountry(e.target.value)} type="name" placeholder='Pakistan' />
      </Form.Group>
      <br />
      <br />
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="I accept terms of service" />
      </Form.Group>

      <Button onClick={submitForm}>Submit</Button>
    </Form>
    </div>
  )
}
