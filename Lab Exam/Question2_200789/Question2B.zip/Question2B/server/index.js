const express = require("express");
const app = express();
const cors = require("cors"); 
const mongoose = require("mongoose");
const userRoute = require("./routes/userRoute");

const connect = () => {
  mongoose.connect(`mongodb://127.0.0.1:27017/LabExam`, {
    useNewUrlParser: true, 
    useUnifiedTopology: true,
  }).then(() => {
    console.log("Successfully connected to database");
  })
  .catch((error) => {
    console.log("database connection failed. exiting now...");
    console.error(error);
    process.exit(1);
  });
};

app.use(express.json());
app.use(cors());

app.use("/user", userRoute);
app.listen(8080, async () => {
  await connect();
  console.log(`Server is connected to port 8080`);
});
