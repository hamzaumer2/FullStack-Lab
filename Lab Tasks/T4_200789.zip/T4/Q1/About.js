import React from 'react';

function About() {
  return (
    <div className="container">
      <h1 className="display-4">About Us</h1>
      <p className="lead">This iss about page.</p>
    </div>
  );
}

export default About;
