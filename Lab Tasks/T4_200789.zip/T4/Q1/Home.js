import React from 'react';

function Home() {
  return (
    <div className="container">
      <h1 className="display-4">Welcome to my Single-Page Application!</h1>
      <p className="lead">This is the Home page.</p>
    </div>
  );
}

export default Home;
